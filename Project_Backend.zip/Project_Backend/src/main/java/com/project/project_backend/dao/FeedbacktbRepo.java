package com.project.project_backend.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.project.project_backend.model.Feedbacktb;

public interface FeedbacktbRepo extends JpaRepository<Feedbacktb, Integer> {

	
}
