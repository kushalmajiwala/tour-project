package com.project.project_backend.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.project.project_backend.model.Tour_mastertb;

public interface Tour_mastertbRepo extends JpaRepository<Tour_mastertb, Integer>{

}
